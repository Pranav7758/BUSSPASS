import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { supabase } from '@/lib/supabase';
import { SidebarLayout } from '@/components/layout/sidebar-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import type { BusRoute, Bus, RouteStop, ActiveTrip, TripStopStatus } from '@shared/schema';
import {
  Bus as BusIcon,
  Clock,
  AlertCircle,
  MapPin,
  CheckCircle2,
  Circle,
  Navigation,
} from 'lucide-react';

interface StopWithStatus extends RouteStop {
  status: TripStopStatus;
  arrived_at: string | null;
  departed_at: string | null;
}

export default function StudentTrackBus() {
  const { student } = useAuth();
  
  const [route, setRoute] = useState<BusRoute | null>(null);
  const [bus, setBus] = useState<Bus | null>(null);
  const [stops, setStops] = useState<StopWithStatus[]>([]);
  const [activeTrip, setActiveTrip] = useState<ActiveTrip | null>(null);
  const [loading, setLoading] = useState(true);

  // Fetch route, bus, and stops data
  useEffect(() => {
    const fetchData = async () => {
      if (!student?.bus_route_id) {
        setLoading(false);
        return;
      }

      // Fetch route
      const { data: routeData } = await supabase
        .from('bus_routes')
        .select('*')
        .eq('id', student.bus_route_id)
        .single();
      if (routeData) setRoute(routeData);

      // Fetch bus on this route
      const { data: busData } = await supabase
        .from('buses')
        .select('*')
        .eq('route_id', student.bus_route_id)
        .eq('is_active', true)
        .single();
      if (busData) setBus(busData);

      // Fetch route stops
      const { data: stopsData } = await supabase
        .from('route_stops')
        .select('*')
        .eq('route_id', student.bus_route_id)
        .order('sequence', { ascending: true });
      
      if (stopsData && stopsData.length > 0) {
        // Initialize stops with pending status
        const stopsWithStatus: StopWithStatus[] = stopsData.map(stop => ({
          ...stop,
          status: 'pending' as TripStopStatus,
          arrived_at: null,
          departed_at: null,
        }));
        setStops(stopsWithStatus);
      }

      setLoading(false);
    };

    fetchData();
  }, [student]);

  // Fetch active trip and subscribe to updates
  useEffect(() => {
    if (!bus || !route) return;

    const fetchActiveTrip = async () => {
      // Get active trip for this bus
      const { data: tripData } = await supabase
        .from('active_trips')
        .select('*')
        .eq('bus_id', bus.id)
        .eq('is_active', true)
        .single();

      if (tripData) {
        setActiveTrip(tripData);
        
        // Fetch stop events for this trip
        const { data: eventData } = await supabase
          .from('trip_stop_events')
          .select('*')
          .eq('trip_id', tripData.id);

        if (eventData) {
          // Update stops with their status
          setStops(prevStops => {
            return prevStops.map(stop => {
              const event = eventData.find(e => e.route_stop_id === stop.id);
              if (event) {
                return {
                  ...stop,
                  status: event.status as TripStopStatus,
                  arrived_at: event.arrived_at,
                  departed_at: event.departed_at,
                };
              }
              return stop;
            });
          });
        }
      } else {
        setActiveTrip(null);
        // Reset all stops to pending
        setStops(prevStops => prevStops.map(stop => ({
          ...stop,
          status: 'pending' as TripStopStatus,
          arrived_at: null,
          departed_at: null,
        })));
      }
    };

    fetchActiveTrip();

    // Subscribe to active_trips changes
    const tripChannel = supabase
      .channel(`active-trip-${bus.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'active_trips',
          filter: `bus_id=eq.${bus.id}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            const trip = payload.new as ActiveTrip;
            if (trip.is_active) {
              setActiveTrip(trip);
            } else {
              setActiveTrip(null);
              // Reset stops when trip ends
              setStops(prevStops => prevStops.map(stop => ({
                ...stop,
                status: 'pending' as TripStopStatus,
                arrived_at: null,
                departed_at: null,
              })));
            }
          }
          if (payload.eventType === 'DELETE') {
            setActiveTrip(null);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(tripChannel);
    };
  }, [bus, route]);

  // Subscribe to trip stop events
  useEffect(() => {
    if (!activeTrip) return;

    const channel = supabase
      .channel(`trip-stops-${activeTrip.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'trip_stop_events',
          filter: `trip_id=eq.${activeTrip.id}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            const event = payload.new as {
              route_stop_id: string;
              status: TripStopStatus;
              arrived_at: string | null;
              departed_at: string | null;
            };
            
            setStops(prevStops => {
              return prevStops.map(stop => {
                if (stop.id === event.route_stop_id) {
                  return {
                    ...stop,
                    status: event.status,
                    arrived_at: event.arrived_at,
                    departed_at: event.departed_at,
                  };
                }
                return stop;
              });
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeTrip]);

  const formatTime = (timestamp: string | null) => {
    if (!timestamp) return '';
    return new Date(timestamp).toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getCurrentStopName = () => {
    const currentStop = stops.find(stop => stop.status === 'arrived');
    if (currentStop) return currentStop.stop_name;
    
    const lastDeparted = [...stops].reverse().find(stop => stop.status === 'departed');
    if (lastDeparted) {
      const nextStopIndex = stops.findIndex(s => s.id === lastDeparted.id) + 1;
      if (nextStopIndex < stops.length) {
        return `En route to ${stops[nextStopIndex].stop_name}`;
      }
    }
    
    return stops.length > 0 ? `Starting from ${stops[0].stop_name}` : 'No stops defined';
  };

  const getProgress = () => {
    if (stops.length === 0) return 0;
    const completedStops = stops.filter(s => s.status === 'departed').length;
    const arrivedStop = stops.find(s => s.status === 'arrived') ? 0.5 : 0;
    return ((completedStops + arrivedStop) / stops.length) * 100;
  };

  if (loading) {
    return (
      <SidebarLayout>
        <div className="space-y-6">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-32" />
          <Skeleton className="h-[400px]" />
        </div>
      </SidebarLayout>
    );
  }

  if (!student?.bus_route_id || !route) {
    return (
      <SidebarLayout>
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-semibold text-foreground">Track Bus</h1>
            <p className="text-muted-foreground mt-1">Real-time bus location</p>
          </div>
          
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16 text-center">
              <AlertCircle className="h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No Route Assigned</h3>
              <p className="text-muted-foreground mt-2 max-w-sm">
                You haven't been assigned to a bus route yet. Please update your profile to select a route.
              </p>
            </CardContent>
          </Card>
        </div>
      </SidebarLayout>
    );
  }

  return (
    <SidebarLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Track Bus</h1>
          <p className="text-muted-foreground mt-1">Real-time bus location</p>
        </div>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <div className={`flex h-14 w-14 items-center justify-center rounded-full ${
                activeTrip ? 'bg-green-100 dark:bg-green-900/30' : 'bg-muted'
              }`}>
                <BusIcon className={`h-7 w-7 ${
                  activeTrip ? 'text-green-600 dark:text-green-400' : 'text-muted-foreground'
                }`} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-lg">{bus?.bus_number || 'No bus'}</span>
                  <Badge variant={activeTrip ? 'default' : 'secondary'}>
                    {activeTrip ? 'Trip Active' : 'No Active Trip'}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {route.route_number} - {route.route_name}
                </p>
                {activeTrip && (
                  <p className="text-sm text-primary mt-1 flex items-center gap-1">
                    <Navigation className="h-3 w-3" />
                    {getCurrentStopName()}
                  </p>
                )}
              </div>
            </div>

            {activeTrip && (
              <div className="mt-4">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-muted-foreground">Trip Progress</span>
                  <span className="font-medium">{Math.round(getProgress())}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-primary rounded-full transition-all duration-500"
                    style={{ width: `${getProgress()}%` }}
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              Bus Stops
            </CardTitle>
          </CardHeader>
          <CardContent>
            {stops.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <MapPin className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No stops defined for this route yet.</p>
                <p className="text-sm mt-1">Contact admin to add stops.</p>
              </div>
            ) : (
              <div className="relative">
                {stops.map((stop, index) => {
                  const isLast = index === stops.length - 1;
                  const isArrived = stop.status === 'arrived';
                  const isDeparted = stop.status === 'departed';
                  const isPending = stop.status === 'pending';
                  
                  return (
                    <div key={stop.id} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div className={`flex h-10 w-10 items-center justify-center rounded-full border-2 transition-all ${
                          isDeparted 
                            ? 'bg-green-500 border-green-500 text-white' 
                            : isArrived 
                              ? 'bg-blue-500 border-blue-500 text-white animate-pulse' 
                              : 'bg-background border-muted-foreground/30 text-muted-foreground'
                        }`}>
                          {isDeparted ? (
                            <CheckCircle2 className="h-5 w-5" />
                          ) : isArrived ? (
                            <BusIcon className="h-5 w-5" />
                          ) : (
                            <Circle className="h-4 w-4" />
                          )}
                        </div>
                        {!isLast && (
                          <div className={`w-0.5 h-16 ${
                            isDeparted ? 'bg-green-500' : 'bg-muted-foreground/20'
                          }`} />
                        )}
                      </div>

                      <div className={`flex-1 pb-6 ${isLast ? '' : ''}`}>
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className={`font-medium ${
                              isArrived ? 'text-blue-600 dark:text-blue-400' : 
                              isDeparted ? 'text-green-600 dark:text-green-400' : ''
                            }`}>
                              {stop.stop_name}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              Stop {stop.sequence}
                            </p>
                          </div>
                          
                          <div className="text-right">
                            {isArrived && (
                              <Badge className="bg-blue-500 hover:bg-blue-600">
                                Bus Here
                              </Badge>
                            )}
                            {isDeparted && (
                              <Badge variant="outline" className="text-green-600 border-green-600">
                                Completed
                              </Badge>
                            )}
                            {isPending && activeTrip && (
                              <Badge variant="outline" className="text-muted-foreground">
                                Upcoming
                              </Badge>
                            )}
                          </div>
                        </div>

                        {(stop.arrived_at || stop.departed_at) && (
                          <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                            {stop.arrived_at && (
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                Arrived: {formatTime(stop.arrived_at)}
                              </span>
                            )}
                            {stop.departed_at && (
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                Departed: {formatTime(stop.departed_at)}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {!activeTrip && (
          <Card className="bg-muted/50">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground text-center">
                No active trip at the moment. The driver will start the trip when the bus begins its route.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </SidebarLayout>
  );
}
